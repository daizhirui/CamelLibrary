typedef unsigned char BYTE;     // these save typing
typedef unsigned short WORD;

extern BYTE connected;         // usb is connected to host or not
void probe_setup();
void CMprobe(unsigned long val);


