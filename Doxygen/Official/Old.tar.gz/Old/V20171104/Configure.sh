#!bin/bash
mkdir -p lib
mkdir -p include
mkdir -p release
cd lib
mkdir -p M2
cd ../include
mkdir -p M2
cd ../release
mkdir -p lib
mkdir -p lib/M2
mkdir -p include
mkdir -p include/M2
echo "DIRECTORIES HAS BEEN CREATED!"