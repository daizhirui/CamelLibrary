//
//  main.c
//  DES
//
//  Created by 戴植锐 on 2018/6/14.
//  Copyright © 2018 戴植锐. All rights reserved.
//

#include <stdio.h>
#include "DES.h"

int main()
{
    DES_Key originalKey;
    originalKey.key = 0x133457799BBCDFF1;
    
    DES_Key* subKeys = DES_generateSubKeys(originalKey);
    for (uint8_t index = 0; index < 17; index++) {
        printf("K%2d = 0x%llx\n", index, subKeys[index].key);
    }
    
    MessageData originalData;
    originalData.data = 0x123456789abcdef;
    printf("originalData = 0x%llx\n", originalData.data);
    MessageData encryptedData = DES_process(originalData, subKeys, DES_ENCRYPT_MODE);
    printf("encryptedData = 0x%llx\n", encryptedData.data);
    MessageData decryptedData = DES_process(encryptedData, subKeys, DES_DECRYPT_MODE);
    printf("decryptedData = 0x%llx\n", decryptedData.data);
}

